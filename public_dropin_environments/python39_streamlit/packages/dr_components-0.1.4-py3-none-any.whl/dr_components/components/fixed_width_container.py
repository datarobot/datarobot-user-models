from streamlit_extras.stylable_container import stylable_container


def fixed_width_container(width, key, bg_color=None, add_padding=False):
    """
    A layout component to display content with the given width and centered in a 'wide' layout app.
    Note: This component should only be used together with st.set_page_config(layout="wide").

    Parameters
    ----------
    width: int
        The width of the container in pixels

    key: str
        Required key that uniquely identifies this container.

    bg_color: str or None
        A CSS background-color value for the container

    add_padding: boolean or None
        Adds padding to the inner container. Defaults to False


    Returns
    -------
    container:
        A styled container to wrap content into
    """

    container = stylable_container(
        key=key,
        css_styles=[
            # Wrapper container definition
            f"""
                {{
                    display: grid;
                }}""",
            # Max width for streamlit components within this container
            f""" > div {{
                    width: 100%;
                    max-width: {width}px;
                    border-radius: 4px;
                    justify-self: center;
                    {f"box-sizing: content-box;" if add_padding else ''}
                    {f"padding: 12px 20px;" if add_padding else ''}
                    {f"background-color: {bg_color};" if bg_color else ''}
                }}
            """,
            # Max width for custom components within this container
            f""" > div > iframe {{
                    max-width: {width}px;
                }}
            """,
            # Hide the style markdown element
            """
                > div:has( > div.stMarkdown > div[data-testid="stMarkdownContainer"] > style) {
                    display:none;
                }
            """,
        ],
    )

    return container
