import streamlit as st

from ..utils import dynamic_component


def button(text, url, accent_type, key, bg_color=None):
    """Create a new instance of "button" to open given urls
    Parameters
    ----------
    text: str
        Text shown on the button

    url: str
        URL to open on click

    accent_type: str
        Type of the button, allows:
            primary
            secondary
            command
            icon
            round-icon
            primary-icon
            attention
            ghost

    key: str
        Key that uniquely identifies this component. Prevents unnecessary re-renders when given

    bg_color: str or None
        A CSS background-color value for the component

    Returns
    -------
    component_value
        Values from the React frontend: { width: int }
    """

    # Hidden span to target the button below it. Streamlit does not provide any standard way to add id or class directly
    # Used to place and handle widths when used within action bar
    st.markdown(f"<span class='{key} hidden'></span>", unsafe_allow_html=True)
    component_value = dynamic_component(
        name="Button",
        props={
            "text": text,
            "url": url,
            "accentType": accent_type,
            "bgColorOverride": bg_color,
        },
        key=key,
        default=None,
    )

    return component_value
