import streamlit as st
from streamlit_extras.stylable_container import stylable_container

from ..utils import dynamic_component, register_callback


def share_button(
    url,
    is_sharing_enabled,
    key,
    bg_color=None,
):
    """Share button which opens a modal with the url to share the app.
    Parameters
    ----------
    is_sharing_enabled: bool
        Whether the app link can be shared or not

    url: str
        The url of the sharable application

    key: str
        Required key that uniquely identifies this component. Also used to control the fullscreen overlay for modal

    bg_color: str or None
        A CSS background-color value for the component

    Returns
    -------
    component_value
        Values from the React frontend: { width: int, show_modal: bool }
        The 'show_modal' value helps to control whether the iframe should be in fullscreen to display the modal
    """

    def _modal_callback(component_key):
        component_state = st.session_state.get(component_key)
        if 'callback' not in component_state:
            return

        _, callback_values, *_ = component_state['callback'].values()
        show = list(callback_values.values())[0]
        if show == 1:
            # When the modal is visible, we have to resize the iframe to fullscreen to imitate the overlay
            st.session_state['show_fullscreen_key'] = component_key
        else:
            st.session_state['show_fullscreen_key'] = None

    css_styles = []
    if 'show_fullscreen_key' in st.session_state and st.session_state['show_fullscreen_key'] == key:
        css_styles.append(
            """
            iframe {
                position: fixed;
                height: 100%;
                width: 100%;
                top: 0;
                left: 0;
                z-index: 1000;
            }
            """
        )

    register_callback(key, _modal_callback, (key,))

    # Hidden span to target the button below it. Streamlit does not provide any standard way to add id or class directly
    # Used to place and handle widths when used within action bar
    st.markdown(f"<span class='{key} hidden'></span>", unsafe_allow_html=True)
    with stylable_container(
        key="fullscreen_" + key,
        css_styles=css_styles,
    ):
        component_value = dynamic_component(
            name="ShareButton",
            props={
                "url": url,
                "isSharingEnabled": is_sharing_enabled,
                "bgColorOverride": bg_color,
            },
            key=key,
            default=None,
        )

        return component_value
