import streamlit as st
from streamlit_extras.stylable_container import stylable_container


def full_width_container(key, bg_color=None):
    """
    A layout component to display content at full width in a 'wide' layout app. It adds safe paddings when used
    together with the right DR sidebar.
    Note: This component should only be used together with st.set_page_config(layout="wide").

    Parameters
    ----------
    key: str
        Required key that uniquely identifies this container.

    bg_color: str or None
        A CSS background-color value for the container

    Returns
    -------
    container:
        A styled container to wrap content into
    """
    header_css = [
        f"""
            {{
                padding: 12px 20px;
                border-radius: 4px;
                {f"background-color: {bg_color};" if bg_color else ''}
            }}
        """
    ]

    # Apply extra right padding if sidebar has been moved
    if st.session_state.get('moved_st_sidebar_right', False):
        style_text = f"""
            <style class='hidden'>
                div.appview-container:has(> div[data-testid="collapsedControl"])
                    div[data-testid="stVerticalBlockBorderWrapper"]:has(div.element-container > div.stMarkdown
                    > div[data-testid="stMarkdownContainer"] > p > span.{key})
                {{
                    padding-right: 20px;
                }}
            </style>
        """
        st.markdown(style_text, unsafe_allow_html=True)

    container = stylable_container(
        key='header_container',
        css_styles=header_css,
    )

    return container
