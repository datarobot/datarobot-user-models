from ..utils import dynamic_component


def info_section(
    key,
    title=None,
    text=None,
    key_values_list=None,
    move_text_below=False,
    title_class_name=None,
    text_class_name=None,
    bg_color=None,
):
    """Create a new instance of "info_section" to render DR styled title, text and/or key-value lists
    Parameters
    ----------
    key: str
        Key that uniquely identifies this component. Prevents unnecessary re-renders when given

    title: str or None
        Info section title

    text: str or None
        Text that will be rendered. Position can be moved with `move_text_below=True`

    key_values_list: list or None
        A list of items to render in a left/right layout. Accepted shape:
        { "label": str, "value": str, "url": str or None }

    move_text_below: boolean or None
        If both text_info and key_value_info are given the text can be forced below the key-value list

    title_class_name: str or None
        Class names to add onto title

    bg_color: str or None
        A CSS background-color value for the component

    Returns
    -------
    None
    """

    component_value = dynamic_component(
        name="InfoSection",
        props={
            "title": title,
            "text": text,
            "keyValuesList": key_values_list,
            "isTextBelow": move_text_below,
            "titleClassName": title_class_name,
            "textClassName": text_class_name,
            "bgColorOverride": bg_color,
        },
        key=key,
        default=None,
    )

    return component_value
