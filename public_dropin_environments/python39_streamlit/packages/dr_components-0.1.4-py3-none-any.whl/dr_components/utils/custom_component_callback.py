import streamlit as st
from streamlit.components.v1 import components


def enable_custom_component_callbacks():
    # Run it only once per session, this will extend the register_widget function used within declare_component
    if "_enabled_cc_callbacks" not in st.session_state:
        components.register_widget = _get_extended_register_widget(components.register_widget)
        st.session_state._enabled_cc_callbacks = True

    # Initiate a list of callbacks for given component keys
    if "registered_callbacks" not in st.session_state:
        st.session_state.registered_callbacks = {}

    # Initiate a list of already handled callbacks for given callback name to avoid rerunning the same request
    if "handled_callbacks" not in st.session_state:
        st.session_state.handled_callbacks = {}


def _get_extended_callback(user_key, callback):
    # Extending the registered callbacks with a timestamp check to avoid duplicate call for the same requests
    # The component state persist through reruns and can only be reset from inside the components themselves
    # To avoid re-rendering and loading the components with a kind of "clear callback" we keep an array of timestamps
    # Each callback now keeps track of already handled requests via timestamps in the session state
    def _extended_callback(*args, **kwargs):
        if callback.__name__ not in st.session_state.handled_callbacks:
            st.session_state.handled_callbacks[callback.__name__] = []

        component_state = st.session_state.get(user_key)
        if component_state and 'callback' in component_state:
            _, _, timestamp = component_state['callback'].values()

            if timestamp not in st.session_state.handled_callbacks[callback.__name__]:
                st.session_state.handled_callbacks[callback.__name__].append(timestamp)
                return callback(*args, **kwargs)

    return _extended_callback


def _get_extended_register_widget(register_widget):
    # Streamlit does not provide a way to define the on_change_handler when declaring a new custom component.
    # The functionality is already there but register_widget is called without defining any callback args
    # Force add any given on_change_handler, args and kwargs with this extension wrapper
    def _extended_register_widget(*args, **kwargs):
        registered_callbacks = st.session_state.get("registered_callbacks")
        user_key = kwargs.get("user_key")
        widget_has_registered_callback = (
            user_key and registered_callbacks and user_key in registered_callbacks
        )

        if widget_has_registered_callback:
            kwargs["on_change_handler"] = _get_extended_callback(
                user_key, registered_callbacks[user_key][0]
            )
            kwargs["args"] = registered_callbacks[user_key][1]
            kwargs["kwargs"] = registered_callbacks[user_key][2]

        return register_widget(*args, **kwargs)

    return _extended_register_widget


def register_callback(key, callback, args=None, kwargs=None):
    if key is not None and callback is not None:
        if args is None:
            args = []

        if kwargs is None:
            kwargs = {}

        st.session_state.registered_callbacks[key] = (
            callback,
            args,
            kwargs,
        )
