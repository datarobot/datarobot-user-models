import streamlit as st


def get_encoded_fa_info_svg():
    svg_content = """
        url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' height='14' width='14' viewBox='0 0 512 512'%3E%3C!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--%3E%3Cpath d='M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336h24V272H216c-13.3 0-24-10.7-24-24s10.7-24 24-24h48c13.3 0 24 10.7 24 24v88h8c13.3 0 24 10.7 24 24s-10.7 24-24 24H216c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z'/%3E%3C/svg%3E")
    """
    return svg_content


def move_st_sidebar_right(theme, apply_dr_style=False):
    """Helper to flip the Streamlit sidebar to the right side of the view
    Parameters
    ----------
    theme: str
        The current active theme dark / light
    apply_dr_style: boolean or None
        Applies some extra styling to the header and sidebar
    Returns
    -------
    """

    border_style = None
    info_icon_style = None
    content_padding = None

    if apply_dr_style:
        content_padding = """
            div[data-testid="stSidebarUserContent"] {
                padding: 3rem 1.5rem;
            }
        """

        # Flip various styles based on given theme
        if theme == "dark":
            border_style = '1px solid rgba(255, 255, 255, 0.1)'
            info_icon_style = 'brightness(0) invert(1)'
        else:
            border_style = '1px solid rgba(0,0,0, 0.1)'
            info_icon_style = 'brightness(0) invert(0.4)'

    if 'moved_st_sidebar_right' not in st.session_state:
        st.session_state['moved_st_sidebar_right'] = True

    style_text = f"""
        <style class='hidden'>
            header[data-testid="stHeader"] {{
                {f"border-bottom: {border_style};" if border_style else ''}
                z-index: 991;
            }}
            
            div[data-testid="collapsedControl"] {{
                top: 3rem;
                right: 0.25rem;
                left: auto;
                height: 100%;
                {f"border-left: {border_style};" if border_style else ''}
                z-index: 990;
            }}
            
            div[data-testid="collapsedControl"] > button {{
                transform: scaleX(-1)
            }}
            
            {f'''
                div[data-testid="collapsedControl"]::after {{
                  content: {get_encoded_fa_info_svg()};
                  display: flex;
                  justify-content: center;
                  filter: {info_icon_style};
                }}
            ''' if info_icon_style else ''}
            
            div.appview-container section[data-testid="stSidebar"]:first-child {{
                top: 3rem;
                order: 2;
                transform: none;
                transition: transform 300ms ease 0s, min-width 300ms ease 0s, max-width 300ms ease 0s;
                z-index: 990;
            }}

            div.appview-container section[data-testid="stSidebar"]:nth-child(2) {{
                top: 3rem;
                order: 2;
                transform: translateX(+336px);
                transition: transform 300ms ease 0s, min-width 300ms ease 0s, max-width 300ms ease 0s;
                z-index: 990;
            }}
            
            @media only screen and (max-width: 767px) {{
              div.appview-container {{
                    place-content: flex-end;
                }}
            }}

            div.appview-container div[data-testid="stSidebarContent"] + div > div {{
                /*Hides the sidebar resize handle, it cannot function properly when flipped to the right*/
                display: none;
            }}
    
            {content_padding if content_padding else ''}
        </style>
    """
    st.markdown(style_text, unsafe_allow_html=True)
