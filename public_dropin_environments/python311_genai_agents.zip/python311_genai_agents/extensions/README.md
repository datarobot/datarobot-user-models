This folder contains dependencies required to use this custom environment for DataRobot Notebooks. 
Please do not modify or delete this folder from your Docker context.
