class MLPiperException(Exception):
    pass
