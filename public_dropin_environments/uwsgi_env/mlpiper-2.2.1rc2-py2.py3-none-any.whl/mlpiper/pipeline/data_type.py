# TODO: rename file to engine_type


class EngineType:
    SPARK_BATCH = "SparkBatch"
    PY_SPARK = "PySpark"
    GENERIC = "Generic"
    REST_MODEL_SERVING = "RestModelServing"
    SAGEMAKER = "SageMaker"
