class ComponentLanguage:
    PYTHON = "Python"
    R = "R"
    JAVA = "Java"
