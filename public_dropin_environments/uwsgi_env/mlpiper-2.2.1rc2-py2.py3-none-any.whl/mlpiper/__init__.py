version = "2.2.1rc2"
__version__ = version
version_suffix = ".post1+dr"  # For DataRobot internal usage
project_name = "mlpiper"
symlink_name = "mlpiper"
jars_folder = "jars"
