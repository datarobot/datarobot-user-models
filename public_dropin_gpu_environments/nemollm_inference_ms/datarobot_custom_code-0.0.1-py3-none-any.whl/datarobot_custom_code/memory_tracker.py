import os
import sys

import psutil
import time
import multiprocessing

from datarobot_custom_code.utils import get_disk_space


def print_process_tree(pid, indent=0):
    try:
        process = psutil.Process(pid)
        rss_mb = process.memory_info().rss / 1024 / 1024
    except psutil.NoSuchProcess:
        print("Process with PID {} not found.".format(pid))
        return
    print("  " * indent + "|- {} [PID {} RSS: {:.1f}]".format(process.name(), pid, rss_mb))
    children = process.children()
    for child in children:
        print_process_tree(child.pid, indent + 1)


def is_running_in_container():
    # Check if running in a container by checking for the existence of the /proc/self/cgroup file
    return os.path.exists('/proc/self/cgroup')


def get_container_memory_limit():
    try:
        # Read the memory limit from the cgroup file
        with open('/sys/fs/cgroup/memory/memory.limit_in_bytes', 'r') as file:
            limit_in_bytes = int(file.read().strip())

        # Convert the limit to megabytes for better readability
        limit_in_megabytes = limit_in_bytes / (1024 ** 2)

        return limit_in_megabytes
    except FileNotFoundError:
        print("Error: Could not find the memory limit file.")
        return None


def get_container_memory_usage():
    try:
        # Read the memory limit from the cgroup file
        with open('/sys/fs/cgroup/memory/memory.usage_in_bytes', 'r') as file:
            usage_in_bytes = int(file.read().strip())

        # Convert the limit to megabytes for better readability
        usage_in_megabytes = usage_in_bytes / (1024 ** 2)

        return usage_in_megabytes
    except FileNotFoundError:
        print("Error: Could not find the memory usage file.")
        return None


def sum_memory_usage(pid):
    # Initialize total memory usage
    total_memory = 0

    # Iterate over the process tree starting from the given PID
    for proc in psutil.Process(pid).children(recursive=True):
        try:
            # Get memory usage of each process
            mem_info = proc.memory_info()
            total_memory += mem_info.rss
        except psutil.NoSuchProcess:
            # Handle the case where the process no longer exists
            pass

    # Convert total memory to MB for readability
    total_memory_mb = total_memory / (1024 * 1024)
    return total_memory_mb


class MemoryTracker:
    def __init__(self, period_sec=10,
                 warning_limit_percentage=80,
                 deployment_id=None,
                 pid_to_track=None,
                 dir_to_track=None):
        self._period_sec = period_sec
        self._warning_limit_percentage = warning_limit_percentage
        self._deployment_id = deployment_id
        self._pid = None
        self._is_running_inside_container = is_running_in_container()
        self._pid_to_track = pid_to_track
        self._dir_to_track =dir_to_track
        print("Memory tracker:")
        print("Period sec:      {}".format(self._period_sec))
        print("Warning percent: {}".format(self._warning_limit_percentage))
        print("Deployment id:   {}".format(self._deployment_id))
        print("In container:    {}".format(self._is_running_inside_container))
        print("PID to track: {}".format(self._pid_to_track))
        print("Dir to track: {}".format(self._dir_to_track))

    def _track_memory(self):
        while True:
            time.sleep(self._period_sec)

            if self._is_running_inside_container:
                memory_usage = get_container_memory_usage()
                memory_limit = get_container_memory_limit()
                print("In Container {:.0f} / {:.0f} MB".format(memory_usage, memory_limit), flush=True)
                memory_percent = (get_container_memory_usage() / get_container_memory_limit()) * 100
            else:
                memory_percent = psutil.virtual_memory().percent
            if memory_percent > self._warning_limit_percentage:
                print(f"WARNING: Memory usage exceeded {self._warning_limit_percentage}%", file=sys.stderr)
            print(f"Memory usage: {memory_percent:.1f}%", flush=True)
            if self._pid_to_track:
                mem_used_by_pid_tree = sum_memory_usage(self._pid_to_track)
                print("Memory usage for PID {}: {:.0f} MB".format(self._pid_to_track, mem_used_by_pid_tree), flush=True)
                print("Process Tree:")
                print_process_tree(self._pid_to_track)

            if self._dir_to_track:
                total_mb, used_mb, free_mb = get_disk_space(self._dir_to_track)
                print("Total: {:,.0f} MB, Used {:,.0f} MB, free {:,.0f} MB".
                      format(total_mb, used_mb, free_mb), flush=True)

    def start(self):
        process = multiprocessing.Process(target=self._track_memory)
        process.daemon = False
        process.start()
        self._pid = process.pid

    def stop(self):
        if self._pid:
            try:
                os.kill(self._pid, 9)
                print("Memory tracking process stopped.")
            except ProcessLookupError:
                print("Memory tracking process not found.")
            self._pid = None


def main():
    tracker = MemoryTracker(period_sec=1, warning_limit_percentage=80, deployment_id="123", pid_to_track=os.getpid())
    tracker.start()

    # Simulate main process doing some work
    time.sleep(30)

    tracker.stop()

    # An example of using the python client to list deployments
    # container_memory_limit = get_container_memory_limit()
    #
    # if container_memory_limit is not None:
    #     print(f"Container Memory Limit: {container_memory_limit} MB")
    # else:
    #     print("No memory limit detected")
    #
    # container_memory_usage = get_container_memory_usage()
    #
    # if container_memory_usage is not None:
    #     print(f"Current Memory Usage: {container_memory_usage} MB")
    # else:
    #     print("No memory usage detected")


if __name__ == "__main__":
    main()
