from abc import ABCMeta, abstractmethod


class Model(object):
    def __init__(self):
        pass

    @abstractmethod
    def infer(self, sample, label):
        """Should return sample, label, inference."""
        pass

    def __del__(self):
        pass
