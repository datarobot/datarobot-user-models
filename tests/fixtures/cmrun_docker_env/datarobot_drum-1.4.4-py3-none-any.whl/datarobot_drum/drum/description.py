version = "1.4.4"
__version__ = version
project_name = "datarobot-drum"
