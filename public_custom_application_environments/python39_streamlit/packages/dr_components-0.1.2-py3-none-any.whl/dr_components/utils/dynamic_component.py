import argparse
import os
import streamlit.components.v1 as components

parser = argparse.ArgumentParser()
parser.add_argument("--localdev", action="store_true", help="Run in local development mode")
args = parser.parse_args()

# For local development add arg --localdev. (streamlit run app_poc.py -- --localdev)
# True will use the build/* files created by npm run build from within ./frontend
# False will use the localhost to serve the frontend by npm run start from within ./frontend
if args.localdev:
    _RELEASE = False
else:
    _RELEASE = True

if not _RELEASE:
    _component_func = components.declare_component(
        "datarobot",
        url="http://localhost:5173",
    )
else:
    current_file_directory = os.path.abspath(__file__)
    build_dir = os.path.abspath(
        os.path.join(current_file_directory, os.pardir, os.pardir, "frontend/build")
    )

    _component_func = components.declare_component("datarobot", path=build_dir)


def dynamic_component(name, props, default=None, key=None):
    return _component_func(name=name, props=props, default=default, key=key)
