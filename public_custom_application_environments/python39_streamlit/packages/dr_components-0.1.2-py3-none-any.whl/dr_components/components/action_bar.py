from streamlit_extras.stylable_container import stylable_container
import streamlit as st
from ..utils import get_markdown_span_selector


def action_bar(content_keys, justify_content, key, add_right_padding=True):
    """Create a new instance of 'action_bar', a container that allows you to add custom components in a horizontal bar
    Parameters
    ----------
    content_keys: [str]
        Text shown on the button

    justify_content: str
        Accepts all CSS values for justify-content
        https://developer.mozilla.org/en-US/docs/Web/CSS/justify-content

    key: str
        Required key that uniquely identifies this component.

    add_right_padding: boolean or None
        By default this component will look for the sidebar placement and add necessary padding to the right side
        Note: Set it to False when used within a full_width_container

    Returns
    -------
    container:
        Container wrapper to be used with custom components
    """
    css_styles = [
        f"""
        {{
            width: 100%;
            display: flex;
            flex-direction: row;
            justify-content: {justify_content};
        }}
        """
    ]

    if add_right_padding and st.session_state.get('moved_st_sidebar_right', False):
        # Apply extra right padding if sidebar has been moved
        style_text = f"""
                <style class='hidden'>
                    div.appview-container:has(> div[data-testid="collapsedControl"])
                        div[data-testid="stVerticalBlock"]:has(> div.element-container > div.stMarkdown
                        > div[data-testid="stMarkdownContainer"] > p > span.{key})
                    {{
                        padding-right: 40px;
                    }}
                </style>
            """
        st.markdown(style_text, unsafe_allow_html=True)

    for content_key in content_keys:
        content_session_state = st.session_state.get(content_key)
        if content_session_state is not None and 'width' in content_session_state:
            # Set precise element width for the containers around the custom component iframe (Default is always 300px)
            css_styles.append(
                f"""
                > div.element-container:has(> {get_markdown_span_selector(content_key)}) + div {{
                    width: {content_session_state['width']}px;
                }}
                """
            )
        else:
            # Before we have the precise width, we can set a static width to minimize the element jumps during render
            css_styles.append(
                f"""
                > div.element-container:has(> {get_markdown_span_selector(content_key)}) + div {{
                    width: 100px;
                }}
                """
            )

    # For justify-content to work with all values, we need to hide all markdown style helper elements
    css_styles.append(
        """
        > div:has( > div.stMarkdown > div[data-testid="stMarkdownContainer"] > style) {
            display:none;
        }
    """
    )

    container = stylable_container(
        key=key,
        css_styles=css_styles,
    )

    return container
