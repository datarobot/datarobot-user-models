import streamlit as st
from streamlit_extras.stylable_container import stylable_container
from ..utils import dynamic_component, get_markdown_span_selector


def util_detect_theme():
    """Helper component to detect the theme set in the browsers localstorage. Streamlit does currently not provide any
    functionality to this more straightforward/

    Parameters
    ----------
    Returns
    -------
    theme: str
        Current active theme name
    """

    util_key = 'util_detect_theme'
    # Hide this util component
    css_styles = [
        f"""
        > div.element-container:has(> {get_markdown_span_selector(util_key)}) + div {{
            height: 0;
            margin-bottom: -1rem;
        }}
        """
    ]

    # Hidden span to target the element below. Streamlit does not provide any standard way to add id or class directly
    # Span class is used to hide the util component below it
    st.markdown(f"<span class='{util_key} hidden'></span>", unsafe_allow_html=True)
    with stylable_container(
        key=util_key,
        css_styles=css_styles,
    ):
        component_value = dynamic_component(
            name="UtilDetectTheme",
            props={},
            key=None,
            default=None,
        )

        return component_value
