import streamlit as st
from streamlit_extras.stylable_container import stylable_container
from ..utils import dynamic_component, register_callback


def chat_history(
    messages,
    min_height=None,
    max_height=None,
    auto_scroll_to=None,
    allow_feedback=None,
    use_st_theme=None,
    key=None,
    on_change=None,
    args=None,
    kwargs=None,
):
    """Create a new instance of "chat_history" to display chat messages from the messages object list
    Parameters
    ----------
    messages: list
        Messages with all relevant information that have been asked and generated so far.

    min_height: number or None
        Minimum height of the chat history custom component

    max_height: number or None
        Maximum height of the chat history custom component

    auto_scroll_to: string or None
        Set 'bottom' or 'top' to automatically scroll the chat in this direction on new messages.
        Defaults to 'bottom' when not set

    allow_feedback: boolean or None
        Enable or disable feedback buttons. Defaults to true in frontend when 'None'

    use_st_theme: list[str] or None
        List of theme keys to apply within the custom component
        Accepts custom theme keys from Streamlit: primaryColor, secondaryBackgroundColor, textColor, font

    key: str or None
        An optional key that uniquely identifies this component. If this is
        None, and the component's arguments are changed, the component will
        be re-mounted in the Streamlit frontend and lose its current state.

    on_change: function
        Callback function that is called whenever the component values change

    args: tuple
        Arguments to pass to the callback function

    kwargs: dict
        Dictionary to pass to the callback function

    Returns
    -------
    None
    """

    def _extend_callback_with_modal_control(cb_function):
        def _extended_callback(*cb_args, **cb_kwargs):
            try:
                component_state = st.session_state.get(key)
                callback_name, callback_values, timestamp = component_state['callback'].values()
                if callback_name != 'show_modal':
                    return
                show = list(callback_values.values())[0]
                handled_callback_key = f'{callback_name}_{key}'
                if handled_callback_key not in st.session_state.handled_callbacks:
                    # Keep track of handled modal overlay callbacks
                    st.session_state.handled_callbacks[handled_callback_key] = []

                if (
                    show
                    and timestamp not in st.session_state.handled_callbacks[handled_callback_key]
                ):
                    # When the modal is visible, we have to resize the iframe to fullscreen to imitate the overlay
                    st.session_state['show_fullscreen_key'] = key
                else:
                    st.session_state['show_fullscreen_key'] = None
            except Exception as e:
                print('Extended show_modal callback encountered an error', e)
            finally:
                return cb_function(*cb_args, **cb_kwargs) if cb_function is not None else None

        return _extended_callback

    css_styles = []
    if 'show_fullscreen_key' in st.session_state and st.session_state['show_fullscreen_key'] == key:
        css_styles.append(
            """
            iframe {
                position: fixed;
                height: 100%;
                width: 100%;
                top: 0;
                left: 0;
                z-index: 1000;
            }
            """
        )

    if min_height and max_height and min_height > max_height:
        raise ValueError("[chat_history] Minimum height must be less than maximum height")

    register_callback(key, _extend_callback_with_modal_control(on_change), args, kwargs)
    with stylable_container(
        key="fullscreen_" + key,
        css_styles=css_styles,
    ):
        component_value = dynamic_component(
            name="ChatHistory",
            props={
                "messages": messages,
                "useStTheme": use_st_theme,
                **({"minHeight": min_height} if min_height is not None else {}),
                **({"maxHeight": max_height} if max_height is not None else {}),
                **({"autoScrollTo": auto_scroll_to} if auto_scroll_to is not None else {}),
                **({"allowFeedback": allow_feedback} if allow_feedback is not None else {}),
            },
            key=key,
            default=None,
        )

        return component_value
