import streamlit as st
from ..utils import dynamic_component, register_callback


def get_prompt_input_value(key):
    component_state = st.session_state.get(key)
    if component_state and 'callback' in component_state:
        callback_name, callback_values, *_ = component_state['callback'].values()

        if callback_name == 'send_prompt':
            prompt = list(callback_values.values())[0]
            return prompt


def prompt_input(
    initials=None,
    gravatar=None,
    input_placeholder=None,
    disabled=False,
    use_st_theme=None,
    key=None,
    on_change=None,
    args=None,
    kwargs=None,
):
    """Create a new instance of "prompt_input".

    Parameters
    ----------
    initials: str or None
        User initials

    gravatar: str or None
        Url to the gravatar image

    input_placeholder: str or None
        Text placeholder on an empty prompt input. Defaults to "Send a prompt"

    disabled: bool or None
        To disable prompting. Defaults to False

    use_st_theme: list[str] or None
        List of theme keys to apply within the custom component
        Accepts custom theme keys from Streamlit: primaryColor, secondaryBackgroundColor, textColor, font

    key: str or None
        An optional key that uniquely identifies this component. If this is
        None, and the component's arguments are changed, the component will
        be re-mounted in the Streamlit frontend and lose its current state.

    on_change: function
        Callback function that is called whenever the component values change

    args: tuple
        Arguments to pass to the callback function

    kwargs: dict
        Dictionary to pass to the callback function

    Returns
    -------
    component_value: str or None
        This is the value passed to `Streamlit.setComponentValue` via submit button on the React frontend.
    """

    register_callback(key, on_change, args, kwargs)
    component_value = dynamic_component(
        name="PromptInput",
        props={
            "userInitials": initials,
            "useStTheme": use_st_theme,
            **({"gravatarUrl": gravatar} if gravatar is not None else {}),
            **({"inputPlaceholder": input_placeholder} if input_placeholder is not None else {}),
            **({"isDisabled": disabled} if disabled is not None else {}),
        },
        key=key,
        default=None,
    )

    return component_value
